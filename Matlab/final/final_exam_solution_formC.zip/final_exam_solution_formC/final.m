clear all; close all; clc; format long
name = '**** ****';
id = 'A******';
hw_num = 'final';
form = 'C';

%% Problem 1: 
load('temperature.dat')

ind_1997 = find(temperature(:,1) == 1997);
sp1a = max(temperature(ind_1997,2:13));
sp1b = find(temperature(ind_1997,2:13) == sp1a);

sp1c = max(max(temperature(:,2:13)));

[row_id, col_id] = find(temperature == sp1c);
sp1d = temperature(row_id,1);


ind_1997 = find(temperature(:,1) == 1997);
ind_2017 = find(temperature(:,1) == 2017);
sp1e = sum(temperature(ind_1997:ind_2017,2:13) > 69,'all');

year = temperature(:,1);
sp1f = mean(temperature(:,4:6),2);


figure(1); hold on;
plot(year,sp1f,'-k');
plot(year(sp1f==max(sp1f)),sp1f(sp1f==max(sp1f)),'ro','MarkerFaceColor','r');
plot(year(sp1f==min(sp1f)),sp1f(sp1f==min(sp1f)),'bo','MarkerFaceColor','b');
xlabel('Year'); ylabel('Temperature (^\circF)'); box on; grid on;
legend('temperature','warmest year','coldest year','location','best');
title('Spring average temperature in San Diego');
sp1g = 'See figure 1' ;
set(gca,'FontSize',14)


%% Problem 2: 
sp2a = 0;
for k = 1:30
    for l = 1:40
        for m = 1:50
            sp2a = sp2a + 1/(3^k + 3^l + 3^m);
        end
    end
end

n = 0;
api = 2*2^n*factorial(n)^2/factorial(2*n+1);
while abs(api-pi) > 1e-5
    n = n+1;
    api = api + 2*2^n*factorial(n)^2/factorial(2*n+1);
end
sp2b = api;
sp2c = n;

x = -14:0.1:14;
y = -12:0.1:12;
for n = 1:length(x)
    for m = 1:length(y)
        f(n,m) = exp(-(cos(x(n)/2)+sin(y(m)/3))^2);
    end
end
counter = 0;
for n = 2:length(x)-1
    for m = 2:length(y)-1
        nb = f(n-1:n+1,m-1:m+1);
        if f(n,m) >= max(nb)
            counter = counter + 1;
            x_lmax(counter) = x(n);
            y_lmax(counter) = y(m);
            f_lmax(counter) = f(n,m);
        end
    end
end
figure(2); hold on;
surf(x,y,f'); shading interp;
plot3(x_lmax,y_lmax,f_lmax,'mo','MarkerFaceColor','m');
xlabel('x'); ylabel('y'); zlabel('f(x,y)');
title('Surface of f(x,y) and local maxima');
view(3); box on; grid on;
set(gca,'FontSize',14);
sp2d = 'See figure 2';

%% Problem 3: 
load('survey.mat')

first_student = strfind(survey{3},'Freshman');
second_student = strfind(survey{end},'Freshman');
sp3a = ~isempty(first_student) && ~isempty(second_student);

first_student = strfind(survey{16},'Freshman');
second_student = strfind(survey{146},'Freshman');
sp3b = ~isempty(first_student) && ~isempty(second_student);

counter = 0;
for n = 1:length(survey)
    local_ind = strfind(survey{n},'Easy');
     if  ~isempty(local_ind)
        counter = counter + 1;
    end
end
sp3c = counter;

counter = 0;
for n = 1:length(survey)
    freshman_cond = strfind(survey{n},'Freshman');
    moderate_cond = strfind(survey{n},'Easy');
     if  ~isempty(freshman_cond) && ~isempty(moderate_cond)
        counter = counter + 1;
    end
end
sp3d = counter;

target = {'Freshman','Sophomore','Junior','Senior','Null'};
for m = 1:length(target)
    counter = 0;
    for n = 1:length(survey)
        local_ind = strfind(survey{n},target{m});
        if  ~isempty(local_ind)
            counter = counter + 1;
        end
    end
    number_student(m) = counter;
end
figure(3);
bar(number_student);
xlabel('class level'); ylabel('number of students');
set(gca,'XTickLabel',target);
title('What is your class level?');
box on; grid on; 
set(gca,'FontSize',14);
sp3e = 'See figure 3';

%% Problem 4: 
load('SDweather.mat')

for n = 1:length(SDweather)
    if SDweather(n).year == 1990
        ind_1990 = n;
        sp4a = min(SDweather(n).temperature);
    end
end
sp4b = find(SDweather(ind_1990).temperature == min(SDweather(ind_1990).temperature));

max_rain_all = 0;
for n = 1:length(SDweather)
    max_rain_yearly = max(SDweather(n).rainfall);
    if max_rain_yearly >  max_rain_all
        max_rain_all = max_rain_yearly;
    end
end
sp4c = max_rain_all;
counter = 0;
for n = 1:length(SDweather)
    if max(SDweather(n).rainfall) == sp4c
        counter = counter + 1;
        year_highest_rain(counter) = SDweather(n).year;
    end
end
sp4d = year_highest_rain;


figure(4); hold on;
bar([SDweather.year],[SDweather.annual_rainfall_avg]);
ind_max = find([SDweather.annual_rainfall_avg] == max([SDweather.annual_rainfall_avg]));
plot(SDweather(ind_max).year, SDweather(ind_max).annual_rainfall_avg, ...
    'cs','MarkerFaceColor','c','MarkerSize',10);
ind_min = find([SDweather.annual_rainfall_avg] == min([SDweather.annual_rainfall_avg]));
plot(SDweather(ind_min).year, SDweather(ind_min).annual_rainfall_avg, ...
    'ys','MarkerFaceColor','y','MarkerSize',10);

legend('rainfall','maximum','minimum')
xlabel('Year'); ylabel('rainfall (in.)');
title('Annual average rainfall in San Diego');
set(gca,'FontSize',14);
box on; grid on;
sp4e = 'See figure 4';

%% Problem 5: 
c = [0, 0.7, 1.4, 2.1, 2.8, 3.5];  

color = 'krbgcm';
for n = 1:length(c)
    [T{n},X{n},V{n}] = spring_mass_damper(c(n));
end

figure(5); hold on;
for n = 1:length(c)
    plot(T{n},X{n},color(n));
    legend_string{n} = sprintf('c = %3.1f',c(n));
end
xlabel('time (s)');
ylabel('Displacement (m)');
title('Displacement in spring-mass-damper system')

legend(legend_string);
box on; grid on;
set(gca,'FontSize',14)
sp5a = 'See figure 5';

for n = 1:length(c)
    counter = 0;
    for m = 2:length(X{n})-1
        if X{n}(m-1) <= X{n}(m) && X{n}(m) >= X{n}(m+1)
            counter = counter + 1;
            T_localmax(counter) = T{n}(m);
        end
    end
    omega(n) = 2*pi/(T_localmax(2) - T_localmax(1));
end
sp5b = omega;