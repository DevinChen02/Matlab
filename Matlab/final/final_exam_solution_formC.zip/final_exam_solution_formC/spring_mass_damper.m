function [T,X,V] = spring_mass_damper(c)
% SPRING_MASS_DAMPER solves the PDE of the spring-mass-damper system with 
% the input damper c and return the time T, displacement X and velocity V 
% of the mass.
% Call format: [T,X,V] = spring_mass_damper(c)

k = 40;
Xo = 0.1;
Vo = 10;
m = 0.1; 

n = 1;
T(n) = 0;
X(n) = Xo;
V(n) = Vo;
dt = 0.001;

while T(n) < 2
    V(n+1) = V(n) - (c/m*V(n) + k/m*X(n))*dt;
    X(n+1) = X(n) + V(n+1)*dt;
    T(n+1) = T(n) + dt;
    n = n + 1;
end


end % function spring_mass_damper